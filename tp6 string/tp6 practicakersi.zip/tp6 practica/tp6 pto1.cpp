#include <stdio.h>
#include <string.h>
#include <conio.h>

main()
{
	char v[51], var[51]; int c = 0, n, aux = 0;
	//x[6] ="final";
	do
	{
		_flushall();
		printf("Ingresar una palabra, para terminar escribir final: ");
		gets(v);
		n = strlen(v); strlwr(v);
		if(n > aux)
		{
		//	printf("%d\n", n);
			var[c]= v[c];
			aux = n;
		}
		c++;
	}
	while(strcmp(v, "final") != 0);
	printf("\n");
	/*for(int i = 0; i < strlen(aux); i++)
	{
		printf("%c", var[i]);
	}*/
	//puts(var);
	printf("\nCantidad de palabras ingresadas:%d", c-1);
	getch();
}