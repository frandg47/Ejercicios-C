#include <stdio.h>
#include <string.h>
#include <conio.h>
typedef char cadena[15];
void cargar(cadena a1[20], int v1[100], int n1);
int may(cadena a1[20], int v1[100], int n1, int &pos);
int asig(cadena a1[20], int v1[100], int n1);
main()
{
	int n, v[100], pos; char aux;
	cadena a[20], k[15];
	printf("Ingresar la cantidad de asignaturas: ");
	scanf("%d", &n);
	cargar(a, v, n);
	may(a, v, n, pos);
	printf("La asignatura con mas inscriptos es:");
	puts(a[pos]);
	
	printf("Cantidad de alumnos:%d", asig(a, v, n));
	getch();
}
void cargar(cadena a1[20], int v1[100], int n1)
{
	for(int i = 0; i < n1; i++)
	{
		printf("Asignatura [%d]\n", i);
		printf("Nombre: ");
		_flushall();
		gets(a1[i]);
	//	puts(a1[i]);
		printf("Cant de alumnos: ");
		scanf("%d", &v1[i]);
		//printf("%d\n", v1[i]);
	}
	/*for(int i = 1; i < n1+1; i++)
	{
		puts(a1[i]);
		printf("%d\n", v1[i]);
	}*/
}
int may(cadena a1[20], int v1[100], int n1, int &pos)
{
	int ax = 0;
	//cadena aux;
	//char aux;
	for(int i = 0; i < n1; i++)
	{
		if(v1[i] > ax)
		{
			//strcpy(aux, a1[i]);
			ax = v1[i];
		//	printf("NUMERO%d\n", ax);
			pos = i;
		}
		//printf("POSICION:%d\n", pos);
	}
	return pos;
}
int asig(cadena a1[20], int v1[100], int n1)
{
	int aux = 0;
	char k[20];
	_flushall();
	printf("Ingresar una asignatura:");
	gets(k);
	for(int i = 0; i < n1; i++)
	{
		if(strcmp(k, a1[i]) == 0)
		{
			aux = v1[i];			
		}
	}
	return aux;
}