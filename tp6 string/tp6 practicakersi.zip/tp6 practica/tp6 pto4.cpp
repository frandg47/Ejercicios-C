#include <stdio.h>
#include <string.h>
#include <conio.h>

main()
{
	char p[201];
	int contv = 0, contc = 0;
	printf("Ingresar un poema de max 200 caracteres:");
	gets(p);
	printf("Poema:");
	puts(p);
	strlwr(p);
	for(int i = 0; i < strlen(p); i++)
	{
		if(p[i] == 97 or p[i]== 101 or p[i]== 105 or p[i]== 111 or p[i]== 117)
		{
			contv++;
		}
		if(p[i] == 98 or p[i] == 99 or p[i] == 100 or p[i] == 102 or p[i] == 103 or p[i] == 104 or p[i] == 106 or p[i] == 107 or p[i] == 108 or p[i] == 109 or p[i] == 110 or p[i] == 112 or p[i] == 113 or p[i] == 114 or p[i] == 115 or p[i] == 116 or p[i] == 118 or p[i] == 119 or p[i] == 120 or p[i] == 121 or p[i] == 122)
		{
			contc++;
		}
	}
	printf("Cantidad de vocales:%d\n", contv);
	printf("Cantidad de consonantes:%d", contc);
	getch();
}