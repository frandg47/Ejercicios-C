#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
typedef char cadena[50];
void cargar(cadena nom1[20], cadena ap1[15], cadena apynom1[35], int n1);
void ordenar(cadena apynom1[35], int n1);
void mostrar(cadena apynom1[35], int n1);
void ordmos(cadena ap1[15], int n1);
main()
{
	cadena nom[20], ap[15], apynom[35];
	int n;
	printf("Ingresar la cantidad de socios: ");
	scanf("%d", &n);
	cargar(nom, ap, apynom, n);
	ordenar(apynom, n);
	mostrar(apynom, n);
	ordmos(ap, n);
	getch();
}
void cargar(cadena nom1[20], cadena ap1[15], cadena apynom1[35], int n1)
{
	for(int i = 0; i < n1; i++)
	{
		printf("Socio [%d]\n", i);
		_flushall();
		printf("Ingresar el nombre: ");
		gets(nom1[i]);
		_flushall();
		printf("Ingresar el apellido: ");
		gets(ap1[i]);
		strcat(apynom1[i],ap1[i]);
		strcat(apynom1[i], ",");
		strcat(apynom1[i], nom1[i]);
		printf("Apellido y nombre ingresados:");
		puts(apynom1[i]);
		getch();
		system("cls");
	}
}
void ordenar(cadena apynom1[35], int n1)
{
	int b;
	cadena aux;
	do
	{
		b=0;
		for (int i=0;i<n1-1;i++)
		{
			strupr(apynom1[i]);
			if (strcmp(apynom1[i],apynom1[i+1])<0)
			{
				strcpy(aux,apynom1[i]);
				strcpy(apynom1[i],apynom1[i+1]);
				strcpy(apynom1[i+1],aux);
				b=1;
			}
		}
	}
	while (b==1);
}
void mostrar(cadena apynom1[35], int n1)
{
	printf("\nLista ordenada decreciente:\n");
	for (int i = 0; i < n1; i++)
	{
		printf("Socio: ",i);
		puts(apynom1[i]);
	}
}
void ordmos(cadena ap1[15], int n1)
{
	int b;
	cadena aux;
	do
	{
		b=0;
		for (int i=0;i<n1-1;i++)
		{
			strupr(ap1[i]);
			if (strcmp(ap1[i],ap1[i+1])<0)
			{
				strcpy(aux,ap1[i]);
				strcpy(ap1[i],ap1[i+1]);
				strcpy(ap1[i+1],aux);
				b=1;
			}
		}
	}
	while (b==1);
	printf("\nApellidos de la A a la Z:\n");
	for(int i = n1-1; i >= 0; i--)
	{
		printf("Socio: ",i);
		puts(ap1[i]);
	}
}